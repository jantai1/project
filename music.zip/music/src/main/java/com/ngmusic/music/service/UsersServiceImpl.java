package com.ngmusic.music.service;

import com.ngmusic.music.entity.User;
import com.ngmusic.music.repository.UsersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
public class UsersServiceImpl implements UsersService {

    @Autowired
    private UsersRepository usersRepository;
    @Autowired
    private PasswordEncoder encoder;

    @Override
    public User addUser(User user) {

        user.setPassword(encoder.encode(user.getPassword()));
        return usersRepository.save(user);
    }

    @Override
    public User fetchUserById(Integer userId) {
        Optional<User> users = usersRepository.findById(userId);

        return users.get();
    }

    @Override
    public User updateUser(Integer userId, User user) {

        User userDB = usersRepository.findById(userId).get();

        if (Objects.nonNull(user.getUsername()) && !"".equalsIgnoreCase(user.getUsername())) {
            userDB.setUsername(user.getUsername());
        }

        return usersRepository.save(userDB);

    }

    @Override
    public void deleteUserById(Integer userId) {
        usersRepository.deleteById(userId);
    }

    @Override
    public List<User> fetchNgUsersList() {
        return usersRepository.findAll();
    }


}
