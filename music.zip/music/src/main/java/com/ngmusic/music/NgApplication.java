package com.ngmusic.music;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NgApplication {

	public static void main(String[] args) {
		SpringApplication.run(NgApplication.class, args);
	}

}
