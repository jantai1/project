package com.ngmusic.music.controller;


import com.ngmusic.music.entity.User;
import com.ngmusic.music.repository.UsersRepository;
import com.ngmusic.music.service.UsersService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
public class UserController {
    @Autowired
    private UsersService usersService;

    private final Logger LOG = LoggerFactory.getLogger(UserController.class);
    @Autowired
    private UsersRepository usersRepository;

    @PostMapping("/users/add")
    public User addUser(@RequestBody User user) {
        LOG.info("Creation of user");
        return usersService.addUser(user);
    }

    @GetMapping("/users/all")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public List<User> fetchUsersList() {
        return usersService.fetchNgUsersList();
    }


    @GetMapping("/users/{id}")
//    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public User fetchUserById(@PathVariable("id") Integer userId) {
        return usersService.fetchUserById(userId);
    }

    @PutMapping("/users/{id}")
//    @PreAuthorize(("hasAuthority('ROLE_USER')"))
    public User updateUser(@PathVariable("id") Integer userId, @RequestBody User user){
        return usersService.updateUser(userId, user);
    }

    @DeleteMapping("/users/{id}")
    public String deleteUserById(@PathVariable("id") Integer userId, @RequestBody User user){
         usersService.deleteUserById(userId);
         return "User Deleted Successfully";
    }

}
