package com.ngmusic.music.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "NgSingers", uniqueConstraints = {@UniqueConstraint(columnNames = {"ngSingersId"})})
public class Singer {


    @Id@GeneratedValue(strategy = GenerationType.AUTO)
    private Integer ngSingersId;
    private String name;
    private Date dob;
    private String sex;


    @OneToMany(mappedBy = "ngSingersId", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private List<Album> albums = new ArrayList<>();





}
