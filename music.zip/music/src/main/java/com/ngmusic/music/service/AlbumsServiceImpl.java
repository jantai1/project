package com.ngmusic.music.service;

import com.ngmusic.music.entity.Album;
import com.ngmusic.music.entity.Singer;
import com.ngmusic.music.repository.AlbumsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

@Service
public class AlbumsServiceImpl implements AlbumsService{

    @Autowired
    AlbumsRepository albumsRepository;

    @Override
    public Album addAlbum(Album album) {
        return albumsRepository.save(album);
    }

//    @Override
//    public void saveAlbumData() {
//        String textLine = "";
//List<Object> object = new ArrayList<>();
//
//        try {
//            BufferedReader reader = new BufferedReader(new FileReader("src/main/resources/ng_singers.txt"));
//            if (!((textLine = reader.readLine()) != null)) {
//
//                String[] data = textLine.split("|");
//
//                Album album = new Album();
//                album.setName(data[0]);
//                album.se
//                album.se
//                album.se
//
//                albumsRepository.save(singer);
//            }
//        } catch (IOException e) {
//            throw new RuntimeException(e);
//        }
//    }
}
