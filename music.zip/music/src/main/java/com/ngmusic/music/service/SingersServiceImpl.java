package com.ngmusic.music.service;

import com.ngmusic.music.entity.Singer;
import com.ngmusic.music.repository.SingersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

@Service
public class SingersServiceImpl implements SingersService {

    @Autowired
    private SingersRepository singersRepository;

//    public SingersServiceImpl(SingersRepository singersRepository){
//        super();
//        this.singersRepository = singersRepository;
//    }

    @Override
    public Singer addSinger(Singer singer) {
        return singersRepository.save(singer);
    }

    @Override
    public List<Singer> getAllSingers() {
        return singersRepository.findAll();
    }

    @Override
    public void saveSingersData() {
        List<Object> objects = new ArrayList<Object>();
        String textLine = "";

        try {
            BufferedReader reader = new BufferedReader(new FileReader("src/main/resources/ng_singers.txt"));
            if (!((textLine = reader.readLine()) != null)) {

                String[] data = textLine.split("|");
                objects = Arrays.asList(data);

                Singer singer = new Singer();
                singer.setName((String) objects.get(0));
                singer.setDob((Date) objects.get(1));
                singer.setSex((String) objects.get(2));

                singersRepository.save(singer);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }


    }
}

