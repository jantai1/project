package com.ngmusic.music.service;

import com.ngmusic.music.entity.Singer;

import java.io.IOException;
import java.util.List;

public interface SingersService {
    public Singer addSinger(Singer singer);

    List<Singer> getAllSingers();

    void saveSingersData();
}
