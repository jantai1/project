package com.ngmusic.music.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "NgAlbums", uniqueConstraints = {@UniqueConstraint(columnNames = {"ngSingersId"})})
public class Album {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer ngAlbumsId;
    private String albumName;
    private String releaseYear;
    private String recordCompany;

    @ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinColumn(name = "ngSingersId")
    private Singer ngSingersId;



}
