package com.ngmusic.music.controller;

import com.ngmusic.music.entity.Singer;
import com.ngmusic.music.service.SingersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;

@RestController
//@RequestMapping("/singers")
public class SingersController {

    @Autowired
    private SingersService singersService;

    @PostMapping("/singers/addSinger")
    public Singer addSinger(@RequestBody Singer singer) {

        return singersService.addSinger(singer);
    }

    @GetMapping("/singers")
    public List<Singer> listSingers(Model model) {

        model.addAttribute("singers", singersService.getAllSingers());
        return singersService.getAllSingers();
    }

    @RequestMapping(path = "feedSingersData")
    public void setDataInDB(){
        singersService.saveSingersData();
    }
}
