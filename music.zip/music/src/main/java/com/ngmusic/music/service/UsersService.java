package com.ngmusic.music.service;

import com.ngmusic.music.entity.User;
import java.util.List;

public interface UsersService {


    public User addUser(User user);
    
    public User fetchUserById(Integer userId);

    public User updateUser(Integer userId, User user);

    public void deleteUserById(Integer userId);

    public List<User> fetchNgUsersList();
    
        

}
