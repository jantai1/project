package com.ngmusic.music.service;

import com.ngmusic.music.entity.Album;

public interface AlbumsService {
    public Album addAlbum(Album album);

//    void saveAlbumData();
}
